---
name: localisation-fr-afrique-ouest
description: Conventions de langue, vocabulaire et format monétaire pour toute l'interface de CotisApp. À utiliser dès que le code touche à un texte affiché à l'utilisateur, un libellé, un message, ou un format de montant.
---

## Langue

Français uniquement pour l'interface, ton simple et direct. Le public cible n'est pas familier du jargon technique — éviter tout anglicisme évitable et tout terme "fintech" abstrait.

## Vocabulaire à privilégier

- "cotisation" (pas "dépôt")
- "part" (pas "action" ni "share")
- "groupe" ou "AVEC" pour désigner l'association (jamais présenter CotisApp comme affilié officiellement à la structure AVEC — voir la note de propriété intellectuelle ci-dessous)
- "agent" pour le gestionnaire du groupe
- "membre" pour les participants

## Format des montants

- Toujours en FCFA, jamais en symbole $ ou €
- Pas de décimales inutiles (le FCFA ne s'utilise pas avec des centimes en usage courant)
- Séparateur de milliers pour la lisibilité (ex. 25 000 FCFA, pas 25000)

## Note de propriété intellectuelle

Ne jamais faire apparaître de texte suggérant que CotisApp est une structure AVEC officielle ou un programme gouvernemental/ONG affilié. "AVEC" est un terme générique décrivant le type de groupe géré par l'app, jamais une marque ou un partenariat à revendiquer.
