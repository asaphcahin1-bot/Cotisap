---
name: avec-business-rules
description: Règles de calcul des cotisations, parts, prêts et répartition de fin de cycle pour les groupes AVEC (Associations Villageoises d'Épargne et de Crédit). À utiliser dès que le code touche au calcul financier d'un groupe, à la structure des parts, aux prêts, aux intérêts, au fonds de solidarité, ou au calcul de répartition de fin de cycle.
---

## Contexte

CotisApp gère des groupes AVEC — un modèle d'épargne communautaire répandu en Afrique de l'Ouest (Côte d'Ivoire, Bénin, Sénégal, Mali, Burkina Faso). Chaque calcul financier doit respecter exactement la mécanique traditionnelle du modèle, décrite ci-dessous — ne pas improviser une variante.

## Structure d'un groupe

- 15 à 30 membres par groupe
- Comité de gestion à 5 rôles : Présidente, Secrétaire, Trésorière, 2 Compteuses
- Cycle de 9 à 12 mois, configurable par groupe
- Réunions hebdomadaires, bimensuelles ou mensuelles, configurable par groupe

## Système de parts

- Chaque membre achète des parts à chaque réunion, entre 1 et 5 parts
- La valeur d'une part est fixée par le groupe en début de cycle (champ configurable, pas une constante)
- Le total de parts d'un membre = somme de toutes ses parts achetées sur le cycle en cours

## Prêts

- Un prêt est toujours facultatif pour le membre
- Taux d'intérêt fixé par le groupe (champ configurable par groupe, pas une constante globale)
- Un prêt ne peut être enregistré au nom d'un membre sans sa confirmation directe (voir le skill `member-consent-rules`)

## Fonds de solidarité

- Caisse séparée du calcul de répartition — jamais incluse dans le calcul de fin de cycle
- Alimentée par des contributions distinctes des parts de cotisation
- Ne jamais faire transiter ce fonds par la même colonne de données que les parts de cotisation

## Calcul de répartition de fin de cycle

Formule exacte à respecter :

1. `total_interets_amendes = somme(intérêts perçus sur tous les prêts du cycle) + somme(amendes collectées sur le cycle)`
2. `valeur_par_part = total_interets_amendes / total_parts_du_groupe`
3. `part_individuelle_membre = valeur_par_part * nombre_de_parts_du_membre`
4. Le montant total reçu par chaque membre en fin de cycle = sa cotisation totale (parts × valeur de la part) + sa `part_individuelle_membre`

Ne jamais diviser à parts égales entre membres — toujours au prorata des parts individuelles.

## Distinction cash vs à distance

Chaque ligne de cotisation doit porter un champ `source` avec deux valeurs possibles uniquement : `cash` (saisie manuelle par l'agent en réunion) ou `distance` (payée via l'app, voir le skill `cotisapp-payment-flow`). Le calcul de répartition doit inclure les deux sources sans distinction de traitement — seule l'origine est tracée, pas le poids dans le calcul.
